package com.scaler.tictactoe.models;

public class Symbol {
    private char character;

    public char getCharacter() {
        return character;
    }

    public Symbol(char character) {
        this.character = character;
    }
}
