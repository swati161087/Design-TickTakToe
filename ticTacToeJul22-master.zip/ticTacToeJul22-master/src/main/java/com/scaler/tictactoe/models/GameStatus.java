package com.scaler.tictactoe.models;

public enum GameStatus {
    IN_PROGRESS,
    DRAW,
    ENDED,
}
