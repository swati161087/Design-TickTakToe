package com.scaler.tictactoe.models;

public enum PlayerType {
    BOT,
    HUMAN,
}
