package com.scaler.tictactoe.models;

public enum BotDifficultyLevel {
    EASY,
    MEDIUM,
    HARD,
}
